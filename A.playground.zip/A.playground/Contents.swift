//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var numbers: [Double] = [12,21,15,20,24]
numbers.sort()
print(numbers)
var c = numbers.max()
print(" \(c) is the smallest Number")
var d = numbers.min()
print("\(d) is the greatest Number")

func average (n: [Double]) -> Double
{
    var t = 0.0
    for i in n{
        t += Double(i)
    }
    let t1 = Double(n.count)
    let avg = t/t1
    return avg
}
var e = average(n: numbers)
print("Total Average is : \(e)")

//test 1.2
 var x1: Int=2
 var y1: Int=2
 var x2: Int=4
 var y2: Int=4
 var h1: Int=2
 var h2: Int=3
 var w1: Int=3
 var w2: Int=4
 
 if (x1+w1<x2 || x2+w2<x1 || y1+h1<y2 || y2+h2<y1) {
 print("No Overlap")
 }
 else
 {
 print("Overlap")
 }

//test1.3
func bin(_ num: Int)
{
    var b=[Int]()
    var r: Int=0
    var t: Int=num
    while t>0 {
        r=t%2
        b.append(r)
        t = t/2

    }
    b.reverse()
   // print("Reverse numbers are",\(b.reverse(t))
   // print("Binary of this numbers is :\//(b)",terminator:"")
}
bin(25)

 

